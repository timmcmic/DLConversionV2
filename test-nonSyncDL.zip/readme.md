Information regarding the use, features, and code changes of the DLConversionV2 module can be found at

https://timmcmic.wordpress.com

Refer to the pinned blog post that is a table of contents.