function write-shamelessPlug
{
    out-logfile -string "*************************************************************"
    out-logfile -string "Shameless plug...this script is developed in my spare time..."
    out-logfile -string "If you are enjoying it - and it is working - consider letting my management know at dlconversionv2@service.microsoft.com"
    out-logfile -string "*************************************************************"
}