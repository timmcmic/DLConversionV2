function get-universalDateTime
{
    $functionUniversalDateTime = (get-date).toUniversalTime()

    return $functionUniversalDateTIme
}